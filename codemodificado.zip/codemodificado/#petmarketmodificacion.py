#petmarketmodificacion
def validar_codigo(codigo, dicc_productos):
    if not codigo or codigo.strip() == "":
        return False
    for clave in dicc_productos.keys():
        if clave.upper() == codigo.upper():
            return False
    return True

def validar_nombre(nombre):
    if not nombre or nombre.strip() == "":
        return False
    return True

def validar_categoria(categoria):
    if not categoria or delete.strip() == "":
        return False
    return True

def validar_marca(marca):
    if not marca or marca.strip() == "":
        return False
    return True

def validar_peso(peso_kg):
    try:
        peso = float(peso_kg)
        return peso > 0
    except ValueError:
        return False

def validar_es_importado(opcion):
    return opcion.lower() in ['s', 'n']

def validar_es_para_cachorro(opcion):
    return opcion.lower() in ['s', 'n']

def validar_precio(precio):
    try:
        valor = int(precio)
        return valor > 0
    except ValueError:
        return False

def validar_unidades(unidades):
    try:
        valor = int(unidades)
        return valor >= 0
    except ValueError:
        return False

def leer_opcion():
    try:
        opcion_input = input("Ingrese opcion: ")
        opcion = int(opcion_input)
        if 1 <= opcion <= 6:
            return opcion
        else:
            return -1
    except ValueError:
        return -1

def unidades_categoria(categoria, dicc_productos, dicc_stock):
    total_unidades = 0
    for codigo, datos in dicc_productos.items():
        if datos[1].lower() == categoria.lower():
            if codigo in dicc_stock:
                total_unidades += dicc_stock[codigo][1]
    
    print(f"El total de unidades disponibles es: {total_unidades}")

def busqueda_precio(p_min, p_max, dicc_productos, dicc_stock):
    """buscar y mostrar productos disponibles dentro de un rango de precios especificos"""
    resultados = []
    for codigo, datos_stock in dicc_stock.items():
        precio = datos_stock[0]
        unidades = datos_stock[1]
        if p_min <= precio <= p_max and unidades > 0:
            nombre = dicc_productos[codigo][0]
            resultados.append(f"{nombre}--{codigo}")
            
    if resultados:
        resultados.sort()
        print(f"Los productos encontrados son: {resultados}")
    else:
        print("No hay productos en ese rango de precios.")

def buscar_codigo(codigo, dicc_productos):
    for clave in dicc_productos.keys():
        if clave.upper() == codigo.upper():
            return True
    return False

def actualizar_precio(codigo, nuevo_precio, dicc_productos, dicc_stock):
    """Actualice el precio de un producto existente en el diccionario de existencias"""
    if buscar_codigo(codigo, dicc_productos):
        for clave in dicc_stock.keys():
            if clave.upper() == codigo.upper():
                dicc_stock[clave][0] = nuevo_precio
                return True
    return False

def agregar_producto(codigo, nombre, categoria, marca, peso_kg, es_importado, es_para_cachorro, precio, unidades, dicc_productos, dicc_stock):
    """Registre un nuevo producto validado en ambos diccionarios relacionales"""
    bool_importado = True if es_importado.lower() == 's' else False
    bool_cachorro = True if es_para_cachorro.lower() == 's' else False
    codigo_clave = codigo.upper()
    
    if codigo_clave in dicc_productos:
        return False
        
    dicc_productos[codigo_clave] = [nombre, categoria, marca, float(peso_kg), bool_importado, bool_cachorro]
    dicc_stock[codigo_clave] = [int(precio), int(unidades)]
    return True

def eliminar_producto(codigo, dicc_productos, dicc_stock):
    """Elimine un registro de producto de ambos diccionarios simultáneamente"""
    if buscar_codigo(codigo, dicc_productos):
        clave_real = None
        for clave in dicc_productos.keys():
            if clave.upper() == codigo.upper():
                clave_real = clave
                break
        if clave_real:
            del dicc_productos[clave_real]
            del dicc_stock[clave_real]
            return True
    return False

def main():
    productos = {
        'M001': ['Alimento Premium', 'comida', 'DogPlus', 10.0, True, False],
        'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8.0, False, False],
        'M003': ['Snack Dental', 'snack', 'BiteJoy', 1.0, True, True],
        'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
        'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
        'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2.0, False, False]
    }
    
    stock = {
        'M001': [32990, 12],
        'M002': [9990, 0],
        'M003': [5490, 25],
        'M004': [7990, 5],
        'M005': [11990, 7],
        'M006': [24990, 3]
    }

    while True:
        print("\n========== MENU PRINCIPAL ==========")
        print("1. Unidades por categoria")
        print("2. Busqueda de productos por rango de precio")
        print("3. Actualizar precio de producto")
        print("4. Agregar producto")
        print("5. Eliminar producto")
        print("6. Salir")
        print("=====================================")
        
        opcion = leer_opcion()
        
        if opcion == -1:
            print("Debe seleccionar una opcion valida")
            continue

        if opcion == 1:
            categoria_buscar = input("Ingrese categoria a consultar: ")
            unidades_categoria(categoria_buscar, productos, stock)
            
        elif opcion == 2:
            while True:
                try:
                    p_min_in = input("Ingrese precio minimo: ")
                    p_min = int(p_min_in)
                    p_max_in = input("Ingrese precio maximo: ")
                    p_max = int(p_max_in)
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        busqueda_precio(p_min, p_max, productos, stock)
                        break
                    else:
                        print("Los valores deben ser positivos y el precio minimo menor o igual al maximo.")
                except ValueError:
                    print("Debe ingresar valores enteros")
                    
        elif opcion == 3:
            while True:
                cod_actualizar = input("Ingrese codigo del producto: ")
                nuevo_precio_in = input("Ingrese nuevo precio: ")
                if validar_precio(nuevo_precio_in):
                    precio_valido = int(nuevo_precio_in)
                    if actualizar_precio(cod_actualizar, precio_valido, productos, stock):
                        print("Precio actualizado")
                    else:
                        print("El codigo no existe")
                else:
                    print("Precio invalido. Debe ser un entero positivo.")
                resp = input("¿Desea actualizar otro precio (s/n)?: ")
                if resp.lower() != 's':
                    break
                    
        elif opcion == 4:
            cod = input("Ingrese codigo del producto: ")
            nom = input("Ingrese nombre: ")
            cat = input("Ingrese categoria: ")
            mar = input("Ingrese marca: ")
            pes = input("Ingrese peso (kg): ")